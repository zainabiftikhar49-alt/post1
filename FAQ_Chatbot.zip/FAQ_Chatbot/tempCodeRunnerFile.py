import nltk
import string

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# Download required NLTK data
nltk.download("punkt", quiet=True)


# -----------------------------------
# FAQ DATASET
# -----------------------------------

questions = [
    "What are the admission requirements?",
    "How can I apply for admission?",
    "When does the semester start?",
    "How can I pay my university fee?",
    "What are the university timings?",
    "How can I contact the university?",
    "Where is the university located?",
    "How can I get my student ID card?",
    "How can I apply for a scholarship?",
    "What documents are required for admission?"
]


answers = [
    "You need to meet the required academic criteria and submit the required documents for admission.",
    "You can apply for admission by completing the university admission form and submitting the required documents.",
    "The semester starts according to the academic calendar announced by the university.",
    "You can pay your university fee through the available bank or online payment methods provided by the university.",
    "University timings are generally from 8:00 AM to 4:00 PM during working days.",
    "You can contact the university through its official phone number, email, or administration office.",
    "The university is located in Lahore, Pakistan.",
    "You can get your student ID card from the university administration or student affairs office.",
    "You can apply for a scholarship by submitting the scholarship application form along with the required documents.",
    "Common documents include educational certificates, CNIC/B-Form, photographs, and other documents required by the university."
]


# -----------------------------------
# TEXT PREPROCESSING
# -----------------------------------

def preprocess(text):
    """
    Convert text to lowercase
    and remove punctuation.
    """

    text = text.lower()

    text = text.translate(
        str.maketrans("", "", string.punctuation)
    )

    return text


# Preprocess all questions
processed_questions = [
    preprocess(question)
    for question in questions
]


# -----------------------------------
# TF-IDF VECTORIZER
# -----------------------------------

vectorizer = TfidfVectorizer()

question_vectors = vectorizer.fit_transform(
    processed_questions
)


# -----------------------------------
# CHATBOT FUNCTION
# -----------------------------------

def get_response(user_question):

    # Preprocess user question
    user_question = preprocess(user_question)

    # Convert user question into TF-IDF vector
    user_vector = vectorizer.transform(
        [user_question]
    )

    # Calculate cosine similarity
    similarities = cosine_similarity(
        user_vector,
        question_vectors
    )

    # Find most similar FAQ
    best_match_index = similarities.argmax()

    best_score = similarities[0][best_match_index]

    # Minimum similarity threshold
    if best_score < 0.20:
        return "Sorry, I don't understand your question. Please ask something related to university FAQs."

    return answers[best_match_index]


# -----------------------------------
# CHATBOT INTERFACE
# -----------------------------------

print("=" * 50)
print("       UNIVERSITY FAQ CHATBOT")
print("=" * 50)

print("Type 'bye' or 'exit' to stop the chatbot.\n")


while True:

    user_input = input("You: ")

    if user_input.lower() in ["bye", "exit", "quit"]:
        print("Bot: Thank you for using the University FAQ Chatbot!")
        break

    response = get_response(user_input)

    print("Bot:", response)